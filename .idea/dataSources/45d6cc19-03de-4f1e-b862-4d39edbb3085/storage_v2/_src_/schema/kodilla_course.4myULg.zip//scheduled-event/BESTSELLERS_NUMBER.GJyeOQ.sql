create definer = root@localhost event BESTSELLERS_NUMBER on schedule
    every '1' MINUTE
        starts '2021-05-09 11:42:05'
    enable
    do
    BEGIN
    INSERT INTO stats (STAT_DATE, STAT, VALUE)
    VALUES (CURDATE(), 'BESTSELLERS', (SELECT * FROM BESTSELLERS_COUNT));
    CALL UpdateBestsellers();
end;

