create
    definer = root@localhost function ShowReadersById(readerid int) returns varchar(255) deterministic
BEGIN
    DECLARE reader VARCHAR(255);
    DECLARE last_name VARCHAR(255);

    SELECT LASTNAME INTO last_name FROM READERS WHERE READER_ID = readerid;

    RETURN reader;
    end;

