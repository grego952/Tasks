create definer = kodilla_user@localhost trigger BOOKS_UPDATE
    after update
    on books
    for each row
BEGIN
    INSERT INTO BOOKS_AUD (EVENT_DATE, EVENT_TYPE, BOOK_ID, NEW_TITLE, NEW_PUBYEAR,
                           NEW_BESTSELLER, OLD_TITLE, OLD_PUBYEAR,
                           OLD_BESTSELLER)
        VALUE(CURTIME(), "UPDATE", OLD.BOOK_ID, NEW.TITLE, NEW.PUBYEAR,
              NEW.BESTSELLER, OLD.TITLE, OLD.PUBYEAR,
              OLD.BESTSELLER);
END;

