create definer = root@localhost view bestsellers_count as
select count(0) AS `COUNT(*)`
from `kodilla_course`.`books`
where (`kodilla_course`.`books`.`BESTSELLER` = 1);

