create definer = kodilla_user@localhost trigger RENTS_INSERT
    after insert
    on rents
    for each row
BEGIN
    INSERT INTO RENTS_AUD (EVENT_DATE, EVENT_TYPE, RENT_ID, NEW_BOOK_ID, NEW_READER_ID,   -- [2]
                           NEW_RENT_DATE, NEW_RETURN_DATE)                                -- [3]
        VALUE(CURTIME(), "INSERT", NEW.RENT_ID, NEW.BOOK_ID, NEW.READER_ID, NEW.RENT_DATE, -- [4]
              NEW.RETURN_DATE);                                                            -- [5]
END;

