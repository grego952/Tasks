create definer = kodilla_user@localhost trigger BOOKS_INSERT
    after insert
    on books
    for each row
BEGIN
    INSERT INTO BOOKS_AUD (EVENT_DATE, EVENT_TYPE, BOOK_ID, NEW_TITLE, NEW_PUBYEAR,
                           NEW_BESTSELLER)                                -- [3]
        VALUE(CURTIME(), "INSERT", NEW.BOOK_ID, NEW.TITLE, NEW.PUBYEAR,
              NEW.BESTSELLER);
END;

