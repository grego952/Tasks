create definer = kodilla_user@localhost trigger RENTS_DELETE
    after delete
    on rents
    for each row
BEGIN
        INSERT INTO rents_aud (EVENT_DATE, EVENT_TYPE, RENT_ID)
        VALUE (CURTIME(), "DELETE", OLD.RENT_ID);
    end;

