create
    definer = root@localhost function CheckRents(RENTS int) returns tinyint(1) deterministic
BEGIN
    DECLARE RESULT BOOLEAN DEFAULT 0;
    IF RENTS > 2 THEN
        SET RESULT = 1;
    end if;
    RETURN RESULT;
end;

