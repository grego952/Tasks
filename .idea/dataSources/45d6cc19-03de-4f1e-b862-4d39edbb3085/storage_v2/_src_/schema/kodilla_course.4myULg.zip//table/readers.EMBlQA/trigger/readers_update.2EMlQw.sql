create definer = kodilla_user@localhost trigger READERS_UPDATE
    after update
    on readers
    for each row
BEGIN
    INSERT INTO READERS_AUD (EVENT_DATE, EVENT_TYPE, READER_ID, NEW_FIRSTNAME, NEW_LASTNAME, NEW_PESELID, NEW_VIP_LEVEL,
                           OLD_FIRSTNAME, OLD_LASTNAME,
                           OLD_PESELID, OLD_VIP_LEVEL)
        VALUE(CURTIME(), "UPDATE", OLD.READER_ID, NEW.FIRSTNAME, NEW.LASTNAME,
              NEW.PESELID, NEW.VIP_LEVEL, OLD.FIRSTNAME, OLD.LASTNAME,
              OLD.PESELID, OLD.VIP_LEVEL);
END;

