create definer = kodilla_user@localhost view books_and_readers as
select `rd`.`READER_ID` AS `READER_ID`,
       `rd`.`FIRSTNAME` AS `FIRSTNAME`,
       `rd`.`LASTNAME`  AS `LASTNAME`,
       `bk`.`TITLE`     AS `TITLE`
from ((`kodilla_course`.`readers` `rd` join `kodilla_course`.`books` `bk`)
         join `kodilla_course`.`rents` `rt`)
where ((`rt`.`BOOK_ID` = `bk`.`BOOK_ID`) and (`rt`.`READER_ID` = `rd`.`READER_ID`))
order by `rt`.`RENT_DATE`;

