create
    definer = root@localhost function VipLevel(booksrented int) returns varchar(20) deterministic
BEGIN
    DECLARE result VARCHAR(20) DEFAULT 'Standard customer';
    IF booksrented >= 10 THEN
        SET result = 'Gold customer';
        ELSEIF booksrented >= 5 AND booksrented < 10 THEN
        SET result = 'Silver customer';
        ELSEIF booksrented >= 2 AND booksrented < 5 THEN
        SET result = 'Bronze customer';
        ELSE
        set result = 'Standard Customer';
        END IF;
    RETURN result;
    end;

