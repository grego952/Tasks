create
    definer = root@localhost procedure CalcPhoneStatus()
BEGIN
    DECLARE K INT(11) DEFAULT 0;
    DECLARE QTY INT(11);
    DELETE FROM phonestats;
    COMMIT ;
    WHILE (K < 100000000) DO
        SELECT COUNT(*)
            FROM phones
                WHERE PHONENUM BETWEEN K-99999 AND K
        INTO QTY;
        INSERT INTO phonestats (RANGE_FROM, RANGE_TO, QUANTITY)
        VALUES (K-99999, K, QTY);
        COMMIT ;
        SET K = K + 100000;
        END WHILE ;
    end;

