create
    definer = root@localhost function ShowReaderById(readerid int) returns varchar(255) deterministic
BEGIN
    DECLARE reader VARCHAR(255);
    IF readerid <= 0 THEN
        SET reader = 'WRONG ID!';
        ELSE
            SELECT LASTNAME INTO reader FROM READERS WHERE READER_ID = readerid;
    end if;
    RETURN reader;
    end;

